---
name: Feature request
about: Create a report to help us improve
title: "[FEATURE] *descriptive_name*"
labels: 'feature'
assignees: ''

---

**Describe the feature request**

A clear and concise description of what the feature would add and why you think it needs to be included.
